<?php
require_once __DIR__ . '/../vendor/autoload.php';

use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;
use Kreait\Firebase\Factory;

$razorpayKeyId = getenv('RAZORPAY_KEY_ID');
$razorpayKeySecret = getenv('RAZORPAY_KEY_SECRET');
$frontendUrl = getenv('FRONTEND_URL') ?: 'https://' . getenv('REPLIT_DEV_DOMAIN') . ':5000';
$firebaseServiceAccount = getenv('FIREBASE_SERVICE_ACCOUNT');

if (!$razorpayKeyId || !$razorpayKeySecret) {
    header("Location: $frontendUrl/payment-failed?error=configuration");
    exit;
}

$success = false;
$paymentId = '';
$firestoreOrderId = '';
$error = '';

if (!empty($_POST['razorpay_payment_id']) && !empty($_POST['razorpay_order_id']) && !empty($_POST['razorpay_signature'])) {
    
    $razorpayOrderId = $_POST['razorpay_order_id'];
    $razorpayPaymentId = $_POST['razorpay_payment_id'];
    $razorpaySignature = $_POST['razorpay_signature'];
    
    $api = new Api($razorpayKeyId, $razorpayKeySecret);
    
    try {
        $attributes = [
            'razorpay_order_id'   => $razorpayOrderId,
            'razorpay_payment_id' => $razorpayPaymentId,
            'razorpay_signature'  => $razorpaySignature
        ];
        
        $api->utility->verifyPaymentSignature($attributes);
        
        if ($firebaseServiceAccount) {
            try {
                $serviceAccountData = json_decode($firebaseServiceAccount, true);
                if (!$serviceAccountData) {
                    throw new Exception('Invalid Firebase service account JSON');
                }
                
                $factory = (new Factory)->withServiceAccount($serviceAccountData);
                $firestore = $factory->createFirestore()->database();
                
                // Get payment record
                $paymentsRef = $firestore->collection('payments');
                $query = $paymentsRef->where('razorpay_order_id', '==', $razorpayOrderId);
                $documents = $query->documents();
                
                if ($documents && !$documents->isEmpty()) {
                    $paymentFound = false;
                    foreach ($documents as $document) {
                        $paymentData = $document->data();
                        $firestoreOrderId = $paymentData['order_id'] ?? null;
                        
                        if (!$firestoreOrderId) {
                            error_log("Payment record missing order_id for Razorpay order: " . $razorpayOrderId);
                            continue;
                        }
                        
                        try {
                            error_log("Attempting to update payment and order. Order ID: $firestoreOrderId");
                            
                            // Update payment record
                            $document->reference()->update([
                                ['path' => 'razorpay_payment_id', 'value' => $razorpayPaymentId],
                                ['path' => 'razorpay_signature', 'value' => $razorpaySignature],
                                ['path' => 'status', 'value' => 'completed'],
                                ['path' => 'updated_at', 'value' => new \Google\Cloud\Core\Timestamp(new \DateTime())]
                            ]);
                            error_log("Payment record updated successfully");
                            
                            // Check if order exists first
                            $orderRef = $firestore->collection('orders')->document($firestoreOrderId);
                            $orderSnapshot = $orderRef->snapshot();
                            
                            if (!$orderSnapshot->exists()) {
                                error_log("ERROR: Order document does not exist: $firestoreOrderId");
                                $error = 'order_not_found';
                                continue;
                            }
                            
                            error_log("Order document exists, attempting update");
                            
                            // Update order record
                            $orderRef->update([
                                ['path' => 'status', 'value' => 'confirmed'],
                                ['path' => 'payment_id', 'value' => $razorpayPaymentId],
                                ['path' => 'payment_signature', 'value' => $razorpaySignature],
                                ['path' => 'payment_status', 'value' => 'completed'],
                                ['path' => 'updated_at', 'value' => new \Google\Cloud\Core\Timestamp(new \DateTime())]
                            ]);
                            
                            error_log("Order updated successfully!");
                            error_log("Payment confirmed: Razorpay Order=$razorpayOrderId, Payment=$razorpayPaymentId, Firestore Order=$firestoreOrderId");
                            $success = true;
                            $paymentId = $razorpayPaymentId;
                            $paymentFound = true;
                            break;
                        } catch (Exception $updateError) {
                            error_log("Firebase update error for order $firestoreOrderId: " . $updateError->getMessage());
                            error_log("Error class: " . get_class($updateError));
                            error_log("Error code: " . $updateError->getCode());
                            error_log("Error trace: " . $updateError->getTraceAsString());
                            $error = 'firebase_update_failed';
                            continue;
                        }
                    }
                    
                    if (!$paymentFound && !$success) {
                        error_log("Could not process any payment records for Razorpay order: " . $razorpayOrderId);
                        $error = 'payment_processing_failed';
                    }
                } else {
                    error_log("No payment records found for Razorpay order: " . $razorpayOrderId);
                    $error = 'payment_record_not_found';
                }
            } catch (Exception $e) {
                error_log("Firebase connection error: " . $e->getMessage());
                error_log("Firebase error trace: " . $e->getTraceAsString());
                error_log("Firebase error class: " . get_class($e));
                error_log("Firebase error code: " . $e->getCode());
                $error = 'firebase_error';
            }
        } else {
            error_log("Firebase service account not configured");
            $error = 'firebase_not_configured';
        }
        
    } catch(SignatureVerificationError $e) {
        $error = 'verification_failed';
    } catch (Exception $e) {
        error_log("Payment verification error: " . $e->getMessage());
        $error = 'unknown_error';
    }
} else {
    $error = 'missing_data';
}

if ($success && $firestoreOrderId) {
    header("Location: $frontendUrl/payment-success?payment_id=$paymentId&order_id=$firestoreOrderId");
} else {
    header("Location: $frontendUrl/payment-failed?error=$error");
}
exit;
